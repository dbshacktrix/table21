package com.dbs.hacktrix.digichits.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dbs.hacktrix.digichits.common.BidderVO;
import com.dbs.hacktrix.digichits.dao.BiddingDAO;
import com.dbs.hacktrix.digichits.services.BiddingService;

@Service("biddingService")
public class BiddingServiceImpl implements BiddingService {
	
	
	@Autowired
	@Qualifier("biddingDAO")
	private BiddingDAO biddingDAO;
	
	public BidderVO bid(BidderVO bidderVO) {
		int commision;
		int totalFund;
		int netBidAmt;
		int benefit;
		int netAmt;
		
		totalFund = bidderVO.getDepositAmt() * bidderVO.getTotalMember();
		commision = (bidderVO.getDepositAmt() * 5) /100;
		netBidAmt = totalFund - bidderVO.getHighestBidAmt();
		benefit = netBidAmt / bidderVO.getTotalMember();
		if(bidderVO.isHighestBidder()) {
			netAmt = netBidAmt + benefit - bidderVO.getDepositAmt() - commision;
		}
		else {
			netAmt = benefit - bidderVO.getDepositAmt() - commision;
		}
		
		bidderVO.setNetAmt(netAmt);
		
		return bidderVO;
	}

	@Override
	public BidderVO submitnBidding(BidderVO bidderVO) {
		
		BidderVO bidderRes = biddingDAO.submitBidding(bidderVO);
		
		return bidderRes;
	}
	
	
}
