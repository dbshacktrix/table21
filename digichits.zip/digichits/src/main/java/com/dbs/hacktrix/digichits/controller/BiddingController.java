package com.dbs.hacktrix.digichits.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dbs.hacktrix.digichits.common.BidderVO;
import com.dbs.hacktrix.digichits.services.BiddingService;



@Controller
@RequestMapping("/ChitFundService")
public class BiddingController {
	
	
	@Autowired
	@Qualifier("biddingService")
	private BiddingService biddingService;

	@RequestMapping(method = RequestMethod.POST, value = "/submitBidding")
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	@ResponseBody
	public BidderVO submitBidding(@RequestBody BidderVO bidderVO) throws Exception{
		
		BidderVO bidderResponse=biddingService.submitnBidding(bidderVO);
		
		return bidderResponse;
	}
}
