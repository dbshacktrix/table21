package com.dbs.hacktrix.digichits.dao;

import com.dbs.hacktrix.digichits.common.BidderVO;

public interface BiddingDAO {

	public BidderVO submitBidding(BidderVO bidderVO);
	
}
