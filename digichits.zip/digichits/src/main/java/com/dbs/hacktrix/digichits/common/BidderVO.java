package com.dbs.hacktrix.digichits.common;

import java.sql.Date;

public class BidderVO {
	int highestBidAmt;
	String userId;
	Date biddingDate;
	int depositAmt;
	int netAmt;
	boolean highestBidder;
	int totalMember;
	
	public int getTotalMember() {
		return totalMember;
	}
	public void setTotalMember(int totalMember) {
		this.totalMember = totalMember;
	}
	public int getHighestBidAmt() {
		return highestBidAmt;
	}
	public void setHighestBidAmt(int highestBidAmt) {
		this.highestBidAmt = highestBidAmt;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getBiddingDate() {
		return biddingDate;
	}
	public void setBiddingDate(Date biddingDate) {
		this.biddingDate = biddingDate;
	}
	public int getDepositAmt() {
		return depositAmt;
	}
	public void setDepositAmt(int depositAmt) {
		this.depositAmt = depositAmt;
	}
	public int getNetAmt() {
		return netAmt;
	}
	public void setNetAmt(int netAmt) {
		this.netAmt = netAmt;
	}
	public boolean isHighestBidder() {
		return highestBidder;
	}
	public void setHighestBidder(boolean highestBidder) {
		this.highestBidder = highestBidder;
	}
	
	
}
