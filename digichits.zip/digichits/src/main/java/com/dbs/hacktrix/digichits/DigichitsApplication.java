package com.dbs.hacktrix.digichits;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigichitsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigichitsApplication.class, args);
	}

}
