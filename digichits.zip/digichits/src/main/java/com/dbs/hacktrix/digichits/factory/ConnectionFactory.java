package com.dbs.hacktrix.digichits.factory;

import java.sql.Connection;
import java.sql.Driver;
import java.util.Properties;

public class ConnectionFactory
{
	private static Connection con=null;
	private static Class c=null;
	private static Properties p=null;
	private static String url=null;
	private static String driverClassName=null;
	static
	{
 		url="jdbc:mysql://localhost:3306/digichits";
		driverClassName="com.mysql.jdbc.Driver";
		p=new Properties();
		p.setProperty("user","root");
		p.setProperty("password","admin");
	};
	
	public static Connection getConnection()
	{
		try
		{
			c=Class.forName(driverClassName);		
			Object o=c.newInstance();
			Driver d=(Driver)o;
			con=d.connect(url,p);
		}catch(Exception e)
		 {
			e.printStackTrace();
		 }
		return con;
	}
}