package com.dbs.hacktrix.digichits.services;

import com.dbs.hacktrix.digichits.common.BidderVO;

public interface BiddingService {

	public BidderVO bid(BidderVO bidderVO);
	
	public BidderVO submitnBidding(BidderVO bidderVO); 
}
