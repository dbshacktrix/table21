package com.dbs.hacktrix.digichits.dao.impl;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.dbs.hacktrix.digichits.common.BidderVO;
import com.dbs.hacktrix.digichits.dao.BiddingDAO;

@Repository
@Qualifier("biddingDAO")
public class BiddingDAOImpl implements BiddingDAO {

	public BidderVO submitBidding(BidderVO bidderVO) {

		
		return null;
	}

}
