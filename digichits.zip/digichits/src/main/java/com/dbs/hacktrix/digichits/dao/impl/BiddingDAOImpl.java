package com.dbs.hacktrix.digichits.dao.impl;

import java.sql.Connection;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.dbs.hacktrix.digichits.common.BidderVO;
import com.dbs.hacktrix.digichits.dao.BiddingDAO;
import com.dbs.hacktrix.digichits.factory.ConnectionFactory;

@Repository
@Qualifier("biddingDAO")
public class BiddingDAOImpl implements BiddingDAO {


	Connection con=null;
	
	public BidderVO submitBidding(BidderVO bidderVO) {

		con=ConnectionFactory.getConnection();
		String sql="insert into bidding values('"+bidderVO.getUserId()+"',"+bidderVO.getDepositAmt()+","+bidderVO.getHighestBidAmt()+","+bidderVO.getBiddingDate()+","+bidderVO.getTotalMember()+")";

		try
		{
			Statement st=con.createStatement();
			st.executeUpdate(sql);
		}catch(Exception s)
		 {
			s.printStackTrace();	 
		 }	     	
		finally
		{	
			try
			{
				con.close();
			}catch(Exception s)
			 { }	     	
		}
		return null;
	}

}
